import "css/style.css"
const News = () => {
    return ( 
        <div>
            <h3 className="special">News组件</h3>
        </div>
     );
}
 
export default News;