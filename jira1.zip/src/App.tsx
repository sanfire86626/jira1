import ProjectListScreen from "screens/project-list";

const App = () => {
  return (
    <div>
      <ProjectListScreen />
    </div>
  );
};

export default App;
